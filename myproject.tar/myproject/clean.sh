rm ticketingsystem/*.class
rm trace 
rm history 
